import { Card, CardContent } from "react";
import { Button } from "react";
import { Input } from "react";
export default function VedastraSena() {
  return (
    <div className="bg-orange-50 min-h-screen text-gray-800">...</div>
  );
}