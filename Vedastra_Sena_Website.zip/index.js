import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import VedastraSena from './VedastraSena';
ReactDOM.render(<VedastraSena />, document.getElementById('root'));